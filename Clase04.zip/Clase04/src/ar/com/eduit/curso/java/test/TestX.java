package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.utils.X;

public class TestX {
    public static void main(String[] args) {
        X.print("Hola");
        X.print(26);
        X.print(true);
        X.print(34.24);
        X.printRed("Hola");
        X.printGreen("Hola");
        X.printBlue("Hola");
    }
}
