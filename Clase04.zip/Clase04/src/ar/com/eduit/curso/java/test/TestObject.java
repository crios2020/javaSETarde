package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Dato;

public class TestObject {
    public static void main(String[] args) {
        Dato d1=new Dato(2);
        Dato d2=d1;
        Dato d3=new Dato(d1.dato);
        Dato d4=new Dato(4);
        String d5="2";
        
        System.out.println("d1.hashCode(): "+d1.hashCode());
        System.out.println("d2.hashCode(): "+d2.hashCode());
        System.out.println("d3.hashCode(): "+d3.hashCode());
        System.out.println("d4.hashCode(): "+d4.hashCode());
        System.out.println("d5.hashCode(): "+d5.hashCode());
        
        System.out.println("d1.equals(d1): "+d1.equals(d1));
        System.out.println("d1.equals(d2): "+d1.equals(d2));
        System.out.println("d1.equals(d3): "+d1.equals(d3));
        System.out.println("d1.equals(d4): "+d1.equals(d4));
        System.out.println("d1.equals(d5): "+d1.equals(d5));
        
    }
}
