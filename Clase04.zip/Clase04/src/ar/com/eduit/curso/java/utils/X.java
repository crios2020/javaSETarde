package ar.com.eduit.curso.java.utils;

public class X {
    
    public static void print(Object obj){
        System.out.println(obj);
    }
    
    public static void printRed(Object obj){
        System.out.println("\033[31m"+obj+"\u001B[0m");
    }
    
    public static void printGreen(Object obj){
        System.out.println("\033[32m"+obj+"\u001B[0m");
    }
        
    public static void printBlue(Object obj){
        System.out.println("\033[34m"+obj+"\u001B[0m");
    }
    
//    public static void print(String text){
//        System.out.println(text);
//    }
//    public static void print(int nro){
//        System.out.println(nro);
//    }
}
