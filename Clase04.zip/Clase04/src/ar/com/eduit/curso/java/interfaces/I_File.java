package ar.com.eduit.curso.java.interfaces;

public interface I_File {
    /*
    Las interfaces:
        - No tiene atributos ni métodos constructores.
        - No hay métodos no abstractos.
        - Solo hay métodos abstractos o atributos estaticos o constantes.
        - Todos los miembros de una interface son publicos.
        - Una clase puede implementar muchas interfaces.
    
    */
    public String nombre="Carlos"; //El stributo es final
    /**
     * La javaDOC es heredada
     * @return 
     */
    String getText();
    void setText(String text);
    
    //Métodos default JDK8 o sup
    default void info(){
        System.out.println("Interface I_File");
    }
    
}
