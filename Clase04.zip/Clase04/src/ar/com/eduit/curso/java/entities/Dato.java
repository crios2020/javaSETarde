package ar.com.eduit.curso.java.entities;

public class Dato {
    public int dato;

    public Dato(int dato) {
        this.dato = dato;
    }

    @Override
    public String toString() {
        return "Dato{" + "dato=" + dato + '}';
    }

    @Override
    public int hashCode() {
        return toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return this.toString().equals(obj.toString());
    }
    
}
