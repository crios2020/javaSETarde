package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;
import ar.com.eduit.curso.java.entities.Vendedor;

public class TestHerencia {
    public static void main(String[] args) {
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1 = new Cuenta(1, "arg$");
        cuenta1.depositar(65000);
        cuenta1.depositar(70000);
        cuenta1.debitar(14000);
        System.out.println(cuenta1);

        System.out.println("-- cuenta2 --");
        Cuenta cuenta2 = new Cuenta(2, "arg$");
        cuenta2.depositar(88000);
        System.out.println(cuenta2);
        
        System.out.println("-- direccion1 --");
        Direccion direccion1 = new Direccion("Larrea", 234, "1", "e");
        System.out.println(direccion1);
        
        System.out.println("-- direccion2 --");
        Direccion direccion2 = new Direccion("San Martin", 23, null, null, "Lujan");
        System.out.println(direccion2);
        
        /*
        System.out.println("-- persona1 --");
        Persona persona1=new Persona("Juana",24,direccion1);
        System.out.println(persona1);
        
        System.out.println("-- persona2 --");
        Persona persona2=new Persona("Cesar",25,persona1.getDireccion());
        System.out.println(persona2);
        */
        
        
        System.out.println("-- vendedor1 --");
        Vendedor vendedor1=new Vendedor(1, 120000, "Mariana", 42, direccion2);
        vendedor1.saludar();
        System.out.println(vendedor1);
        
        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente(1, cuenta2, "Carlos", 48, direccion2);
        cliente1.saludar();
        System.out.println(cliente1);
        
        Object obj=cliente1;
        obj=2;
        
        System.out.println(cliente1.getClass());
        System.out.println(cliente1.getClass().getName());
        System.out.println(cliente1.getClass().getSimpleName());
        System.out.println(cliente1.getClass().getSuperclass().getName());
        System.out.println(cliente1.getClass().getSuperclass().getSuperclass().getName());
        System.out.println(cliente1.getClass().getSuperclass().getSuperclass().getSuperclass());
        String texto="hola";
        System.out.println(texto.getClass().getName());
        System.out.println(texto.getClass().getSuperclass().getName());
        
        //Polimorfismo
        Persona p1 = new Vendedor(2,80000,"Claudio",54,direccion1);
        Persona p2 = new Cliente(2,cuenta1,"Federico",33,direccion2);
        p1.saludar();
        p2.saludar();
        
        //Vendedor v1=(Vendedor)p1;
        Vendedor v1=(p1 instanceof Vendedor)?(Vendedor)p1:null;
        
        
        
    }
}
