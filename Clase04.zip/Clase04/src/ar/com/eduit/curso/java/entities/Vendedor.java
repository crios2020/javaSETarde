package ar.com.eduit.curso.java.entities;

public class Vendedor extends Persona{
    private int nroLegajo;
    private double sueldoBasico;

    public Vendedor(int nroLegajo, double sueldoBasico, String nombre, int edad, Direccion direccion) {
        super(nombre, edad, direccion);
        this.nroLegajo = nroLegajo;
        this.sueldoBasico = sueldoBasico;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 73 * hash + this.nroLegajo;
        hash = 73 * hash + (int) (Double.doubleToLongBits(this.sueldoBasico) ^ (Double.doubleToLongBits(this.sueldoBasico) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Vendedor other = (Vendedor) obj;
        if (this.nroLegajo != other.nroLegajo) {
            return false;
        }
        if (Double.doubleToLongBits(this.sueldoBasico) != Double.doubleToLongBits(other.sueldoBasico)) {
            return false;
        }
        return true;
    }

    @Override
    public void saludar() {
        System.out.println("Hola soy un vendedor!");
    }

    @Override
    public String toString() {
        return "Vendedor{" + "nroLegajo=" + nroLegajo + ", sueldoBasico=" + sueldoBasico + '}' +super.toString();
    }

    public int getNroLegajo() {
        return nroLegajo;
    }

    public double getSueldoBasico() {
        return sueldoBasico;
    }

}
