package ar.com.eduit.curso.java.entities;

public class Direccion {
    private String calle;
    private int nro;
    private String piso;
    private String departamento;
    private String ciudad;

    /**
     * Constructor para direcciones de Ciudad Autonoma de Buenos Aires.
     */
    public Direccion(String calle, int nro, String piso, String departamento) {
        this.calle = calle;
        this.nro = nro;
        this.piso = piso;
        this.departamento = departamento;
        this.ciudad = "CABA";
    }

    public Direccion(String calle, int nro, String piso, String departamento, String ciudad) {
        this.calle = calle;
        this.nro = nro;
        this.piso = piso;
        this.departamento = departamento;
        this.ciudad = ciudad;
    }

    @Override
    public String toString() {
        return "Direccion{" + "calle=" + calle + ", nro=" + nro + ", piso=" + piso + ", departamento=" + departamento + ", ciudad=" + ciudad + '}';
    }

    public String getCalle() {
        return calle;
    }

    public int getNro() {
        return nro;
    }

    public String getPiso() {
        return piso;
    }

    public String getDepartamento() {
        return departamento;
    }

    public String getCiudad() {
        return ciudad;
    }
           
}
