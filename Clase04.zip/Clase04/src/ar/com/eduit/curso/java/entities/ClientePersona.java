package ar.com.eduit.curso.java.entities;

import java.util.Objects;

public class ClientePersona {
    private int nro;
    private String nombre;
    private int edad;
    private Cuenta cuenta;
    
    // Un cliente puede crearse sin una cuenta.
    //public ClientePersona(int nro, String nombre, int edad){
    //    this.nro = nro;
    //    this.nombre = nombre;
    //    this.edad = edad;
    //}
    
    // Un cliente siempre se crea con una cuenta.
    // La cuenta ya debe estar creada y puede ser compartida con otro cliente.
    public ClientePersona(int nro, String nombre, int edad, Cuenta cuenta){
        this.nro = nro;
        this.nombre = nombre;
        this.edad = edad;
        this.cuenta = cuenta;
    }
    
    // Un cliente siempre se crea con una cuenta.
    // La cuenta se le crea y es propia de ese cliente, no compartida.
    public ClientePersona(int nro, String nombre, int edad, int nroCuenta){
        this.nro = nro;
        this.nombre = nombre;
        this.edad = edad;
        this.cuenta = new Cuenta(nroCuenta, "arg$");
    }
    
    public void comprar(){
        if(this.cuenta.getSaldo()>=10){
            this.cuenta.debitar(10);
            System.out.println("Se realizo una comprar de 10$");
        }else{
            System.out.println("No se pudo comprar!");
        }
    }

    @Override
    public String toString() {
        return "ClientePersona{" + "nro=" + nro + ", nombre=" + nombre + ", edad=" + edad + ", cuenta=" + cuenta + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + this.nro;
        hash = 53 * hash + Objects.hashCode(this.nombre);
        hash = 53 * hash + this.edad;
        hash = 53 * hash + Objects.hashCode(this.cuenta);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ClientePersona other = (ClientePersona) obj;
        if (this.nro != other.nro) {
            return false;
        }
        if (this.edad != other.edad) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.cuenta, other.cuenta)) {
            return false;
        }
        return true;
    }

    public int getNro() {
        return nro;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }
    
}
