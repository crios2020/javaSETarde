package ar.com.eduit.curso.java.interfaces;

public class FileText implements I_File {

    @Override
    public String getText() {
        return "Archivo de texto!";
    }

    @Override
    public void setText(String text) {
        System.out.println("Escribiendo Archivo de texto");
    }
    
}
