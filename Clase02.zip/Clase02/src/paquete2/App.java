package paquete2;

import clase02.Auto;

public class App {
    public static void main(String[] args) {
        Auto auto=new Auto("Peugeot","2008","Negro");
        auto.acelerar();
        System.out.println(auto.toString());
    }
}
