package clase02;
    
//Declaración de clases
public class Auto {
    
    //Atributos
    String marca;
    String modelo;
    String color;
    int velocidad;
    
    //Constructores
    
    /**
     * Este método fue deprecado por Carlos Ríos el 22/7/2021 por ser inseguro
     * usar en su reemplazo Auto(String marca, String modelo, String color)
     * @deprecated
     */
    @Deprecated
    Auto() {} //Constructor Vacio
    public Auto(String marca, String modelo, String color){
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
    }
    
    
    //Métodos
    public void acelerar(){                            //acelerar
        //velocidad+=10;
        //if(velocidad>100) velocidad=100;
        acelerar(10);   //Llamado de método dentro de la misma clase
    }
    
    //método sobrecargado
    void acelerar(int kilometros){              //acelerarInt
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }
    
    //void acelerar(int s, int w){                //acelerarIntInt   
    //}
    
    //void acelerar(String x,int e){              //acelerarStringInt
    //}
    
    void frenar(){
        velocidad-=10;
    }
    
    void imprimirVelocidad(){
        System.out.println(velocidad);
    }
    
    int getVelocidad(){
        return velocidad;
    }
    
    @Override
    public String toString(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }
}
