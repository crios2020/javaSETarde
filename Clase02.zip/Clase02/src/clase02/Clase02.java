package clase02;

import javax.swing.JOptionPane;

public class Clase02 {
    public static void main(String[] args) {
        // Claseo 02 POO Programación Orientada a Objetos
        
        // Tipo de datos var JDK 9 o sup.
        
        var var1=2;             // int
        var1=50;
        //var1=50.0;            //error
        
        var var2=2L;            //long
        var var3=2.0;           //double
        var var4=2.0d;          //double
        var var5=2.0f;          //float
        var var6=true;          //boolean
        var var7='A';           //char
        var var8="A";           //String
        
        
        /*
        Que es una clase?
            Las clases representan cosas sustantivas, Se escriben en singular y la primer letra en mayusculas.
        Ej: Persona, Alumno, Producto, Automovil
        
        Clase en Java: Las clases en Java son Objetos de la clase java.lang.Class
        
        Que es un Objeto?
            Es una instancia en particular de la clase. Y tiene estado propio (Valor en sus atributos)
        
        Que es un atributo?
            Los atributos describen (adjetivos) a la clase, son variables contenidas dentro de una clase.
            Tienen un tipo de datos asignado, tienen un proceso de inicialización.
        
        Atributos en Java: Son atributos de la clase java.lang.reflect.Field
        
        
        Que es un método?
            Los métodos son acciones (verbos) que realiza la clase, pueden existir parametros
            de entrada o salida.
        
        Métodos en Java: Son atributos de la clase java.lang.reflect.Method
        
        Sobrecarga de métodos: Ocurre cuando en una clase, existen dos o más métodos
        con el mismo nombre, pero con diferente firma de parametros de entrada.
        
        Métodos constructores: Los métodos constructores inicializan un objetos. 
        Pueden recibir parametros de entrada, no tienen devolución de valor
        y tienen el mismo nombre que la clase, Los constructores pueden ser
        sobrecargados.
        
        Constructores en Java: los constructores son objetos de la clase java.lang.reflect.Constructor
        Si la clase no tienen java en tiempo de compilación agrega un constructor vacio.
        
        */
        
        System.out.println("-- auto1 --");
        Auto auto1=new Auto();
        auto1.marca="Fiat";
        auto1.modelo="Idea";
        auto1.color="Verde";
        
        auto1.acelerar();               //10
        auto1.acelerar();               //20
        auto1.acelerar();               //30
        auto1.frenar();                 //20
        auto1.acelerar(12);             //32
        
        
        
        System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);
        
        Auto auto2=new Auto();
        auto2.marca="Ford";
        auto2.modelo="Ka";
        auto2.color="Negro";
        
        for(int a=0;a<45;a++) auto2.acelerar();
        System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);
        
        
        
        int x;
        String texto;
        //System.out.println(x);            //Error la varaible debe ser inicializado
        //System.out.println(texto);        //Error la varaible debe ser inicializado
        
        System.out.println("-- auto3 --");
        Auto auto3=new Auto("WV", "GOL", "Blanco");
        auto3.acelerar(35);
        auto3.imprimirVelocidad();
        System.out.println(auto3.getVelocidad());
        
        int velocidadAuto3=auto3.getVelocidad();
        
        //JOptionPane.showMessageDialog(null, "Velocidad: "+auto3.getVelocidad());
        
        //Método .toString()
        System.out.println(auto3.toString());
        System.out.println(auto3);
        
        /*
        Modificadores de Visibilidad para miembros de clases (Atributos o Métodos)
        
        Modificador             Alcance
        default(omitido)        Los miembros de clases, pueden ser accedidos desde la misma clase 
                                o desde clases del mismo paquete.
        
        public                  Los miembros de clases, pueden ser accedidos desde cualquier clase
                                de cualquier paquete.
        
        private                 Los miembros de clases, solo son accedidos desde la misma clase.
        
        
        
        */
        
        Empleado empleado1=new Empleado(1, "Juana", "Gala", 50000);
        
        //empleado1.sueldoBasico=9999999;
        empleado1.setSueldoBasico(99999999);
        
        
        System.out.println(empleado1);
        
    }
    
}
