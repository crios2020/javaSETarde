package ar.com.eduit.curso.java.repositories.jdbc;

public class CursoRepository {
    
}
