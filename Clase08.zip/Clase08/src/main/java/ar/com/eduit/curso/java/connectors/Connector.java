package ar.com.eduit.curso.java.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {
    private String url="jdbc:mysql://localhost:3306/colegio";
    private String user="root";
    private String pass="";
    
    public Connection getConnection(){
        try{
            //Class.forName("com.mysql.jdbc.Driver");
            return DriverManager.getConnection(url, user, pass);
        }catch(Exception e){
            System.out.println(e);
            return null;
        }
    }
}
