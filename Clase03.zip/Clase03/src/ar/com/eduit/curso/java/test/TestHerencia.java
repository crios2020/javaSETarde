package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;

public class TestHerencia {
    public static void main(String[] args) {
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1 = new Cuenta(1, "arg$");
        cuenta1.depositar(65000);
        cuenta1.depositar(70000);
        cuenta1.debitar(14000);
        System.out.println(cuenta1);

        System.out.println("-- cuenta2 --");
        Cuenta cuenta2 = new Cuenta(2, "arg$");
        cuenta2.depositar(88000);
        System.out.println(cuenta2);
        
        System.out.println("-- direccion1 --");
        Direccion direccion1 = new Direccion("Larrea", 234, "1", "e");
        System.out.println(direccion1);
        
        System.out.println("-- direccion2 --");
        Direccion direccion2 = new Direccion("San Martin", 23, null, null, "Lujan");
        System.out.println(direccion2);
        
        /*
        System.out.println("-- persona1 --");
        Persona persona1=new Persona("Juana",24,direccion1);
        System.out.println(persona1);
        
        System.out.println("-- persona2 --");
        Persona persona2=new Persona("Cesar",25,persona1.getDireccion());
        System.out.println(persona2);
        */
        
        
        // Falta Método Abstracto
        
        
        
    }
}
