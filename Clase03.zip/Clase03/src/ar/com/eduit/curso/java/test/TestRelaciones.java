package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.ClienteEmpresa;
import ar.com.eduit.curso.java.entities.ClientePersona;
import ar.com.eduit.curso.java.entities.Cuenta;
import java.util.List;

public class TestRelaciones {

    public static void main(String[] args) {

        System.out.println("-- cuenta1 --");
        Cuenta cuenta1 = new Cuenta(1, "arg$");
        cuenta1.depositar(65000);
        cuenta1.depositar(70000);
        cuenta1.debitar(14000);
        System.out.println(cuenta1);

        System.out.println("-- cuenta2 --");
        Cuenta cuenta2 = new Cuenta(2, "arg$");
        cuenta2.depositar(88000);
        System.out.println(cuenta2);

        System.out.println("-- clientePersona1 --");
        ClientePersona clientePersona1 = new ClientePersona(1, "Lucia", 32, new Cuenta(2, "arg$"));
        clientePersona1.comprar();
        clientePersona1.getCuenta().depositar(50000);
        clientePersona1.comprar();
        clientePersona1.getCuenta().debitar(10000);
        System.out.println(clientePersona1);

        System.out.println("-- clientePersona2 --"); // esposo de Lucia
        ClientePersona clientePersona2 = new ClientePersona(2, "Manuel", 32, clientePersona1.getCuenta());

        Cuenta cuentaManuel = clientePersona2.getCuenta();
        cuentaManuel.debitar(10000);

        clientePersona2
                .getCuenta()
                .debitar(10000);

        System.out.println(clientePersona2);
        System.out.println(clientePersona1);

        System.out.println("-- clientePersona3 --");
        ClientePersona clientePersona3 = new ClientePersona(3, "Veronica", 38, 3);
        clientePersona3.getCuenta().depositar(120000);
        clientePersona3.comprar();
        System.out.println(clientePersona3);

        System.out.println("-- clienteEmpresa1 --");
        ClienteEmpresa clienteEmpresa1 = new ClienteEmpresa(1, "Todo Limpio SQL", "Lima 222");
        List<Cuenta> cuentas = clienteEmpresa1.getCuentas();
        cuentas.add(new Cuenta(10, "arg$"));             // 0
        cuentas.add(new Cuenta(11, "reales"));           // 1
        cuentas.add(new Cuenta(12, "U$D"));              // 2

        cuentas.get(0).depositar(350000);
        cuentas.get(0).depositar(180000);
        cuentas.get(0).debitar(60000);
        cuentas.get(1).depositar(48000);
        cuentas.get(2).depositar(12000);

        System.out.println(clienteEmpresa1);
        for(int a=0;a<cuentas.size();a++) System.out.println(cuentas.get(a));
        //for(Cuenta c:cuentas) System.out.println(c);
        

    }
}
