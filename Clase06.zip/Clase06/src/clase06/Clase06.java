package clase06;

//import java.util.*;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;
import java.util.Vector;

public class Clase06 {

    public static void main(String[] args) {
        // Clase 06 Collecciones
        
        
        // Declaración de Vector o Array
        Auto[] autos=new Auto[4];
        autos[0]=new Auto("Fiat","Idea","Rojo");
        autos[1]=new Auto("Ford","Ka","Negro");
        autos[2]=new Auto("VW","Up","Blanco");
        autos[3]=new Auto("Citroen","C4","Bordo");
        
        // recorrido con indices del vector
        //for(int a=0;a<autos.length;a++) System.out.println(autos[a]);
        
        // Recorrido forEach    JDK 5 o sup.
        for(Auto a:autos) System.out.println(a);
        
        
        //Frameworks Collections
        
        //Interface List: Representa un vector dinamico con indices
        //
        
        List lista;
        
        lista=new ArrayList();
        //lista=new LinkedList();
        //lista=new Vector();
                
        lista.add(new Auto("Peugeot","Partner","Negro"));           //0
        lista.add(new Auto("Citroen","Berlingo","Blanco"));         //1
        lista.add("Hola");                                          //2
        lista.add("Chau");                                          //3
        lista.add(22);                                              //4
        lista.remove(3);
        
        //Copiar Autos del vector autos a lista:
        for(Auto a:autos) lista.add(a);
        
        System.out.println("****************************************************");
        
        //Recorrido con indices
        //for(int a=0;a<lista.size();a++) System.out.println(lista.get(a));
        
        //Recorrido forEach
        //for(Object o:lista) System.out.println(o);
        
        //método .forEach()
        //lista.forEach(o->System.out.println(o));
        //lista.forEach(o->{
        //    System.out.println(o);
        //});
        
        lista.forEach(System.out::println);
        
        List listx=new ArrayList();
        lista.forEach(o->listx.add(0));
        lista.forEach(listx::add);
        
        //Uso de Generics<>       JDK 5 o sup
        List<Auto> lista2=new ArrayList();
        lista2.add(new Auto("VW","Gol","Rojo"));
        
        Auto a1=(Auto)lista.get(0);
        Auto a2=lista2.get(0);
        
        //Copiar los autos de lista a lista2
        lista.forEach(o->{
            if(o instanceof Auto) lista2.add((Auto)o);
        });
        
        
        System.out.println("****************************************************");
        lista2.forEach(System.out::println);
      
        
        // Interface Set: Representa un lista sin indices y sin valores duplicados.
        
        Set<String>set=null;
        
        // Implementación HashSet: Es la implementación más veloz, 
        // no garantiza el orden de los elementos.
        //set=new HashSet();
        
        // Implementación LinkedHashSet: Almacena elementos en una lista enlazada por orden de ingreso
        // set=new LinkedHashSet();
        
        // Implementación TreeSet: Almacena elementos en un arbol, por orden natural
        set=new TreeSet();
        
        set.addAll(List.of("Rojo","Verde","Azul","Azul"));
        
        //app
        set.add("Lunes");
        set.add("Martes");
        set.add("Miércoles");
        set.add("Jueves");
        set.add("Viernes");
        set.add("Sábado");
        set.add("Domingo");
        set.add("Lunes");
        set.add("Lunes");
        set.add("Viernes");
        System.out.println("****************************************************");
        set.forEach(System.out::println);
        
        //Set<Auto>setAutos=new LinkedHashSet();
        Set<Auto>setAutos=new TreeSet();
        setAutos.addAll(lista2);
        setAutos.add(new Auto("Citroen","C4","Bordo"));
        setAutos.add(lista2.get(0));
        
        System.out.println("****************************************************");
        setAutos.forEach(auto->System.out.println(auto+"\t"+auto.hashCode()));
        
        
        //Pilas y Colas
        Stack<String>pila=new Stack();
        ArrayDeque<String>cola=new ArrayDeque();
        
        pila.push("Elemento1"); //apila un elemento
        pila.push("Elemento2");
        pila.push("Elemento3");
        pila.push("Elemento4");
        pila.push("Elemento5");
        pila.push("Elemento6");
        
        
        cola.offer("Elemento1");    //encola un elemento
        cola.offer("Elemento2");
        cola.offer("Elemento3");
        cola.offer("Elemento4");
        cola.offer("Elemento5");
        cola.offer("Elemento6");
        
        //System.out.println(pila.pop()); //desapilo un elemento
        //System.out.println(cola.pop()); //desencola un elemento
        
        while(!pila.isEmpty()){
            System.out.println(pila.pop());
        }
        
        while(!cola.isEmpty()){
            System.out.println(cola.pop());
        }
    }
    
}
