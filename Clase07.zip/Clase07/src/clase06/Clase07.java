package clase06;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class Clase07 {
    public static void main(String[] args) {
        Map<String,String>map;
        
        //implementación Hashtable: Es desordenada y obsoleta, No Usar
        //map=new Hashtable();
        
        //implementación HashMap: Es la más veloz y es desordenada
        //map=new HashMap();
        
        //implementación LinkedHashMap: Almacena elementos por orden de ingreso
        //map=new LinkedHashMap();
        
        //implementación TreeSet:   Almacena elementos en una arbol por orden natural de la Key
        map=new TreeMap();
        
        map.put("lu", "Lunes");
        map.put("ma", "Martes");
        map.put("mi", "Miércoles");
        map.put("ju", "Jueves");
        map.put("vi", "Viernes");
        map.put("sa", "Sábado");
        map.put("do", "Domingo");
        
        System.out.println(map.get("ma"));
        //map.forEach((k,v)->System.out.println(k+": "+v));
        Iterator <Entry<String,String>> ite=map.entrySet().iterator();
        while(ite.hasNext()){
            Entry<String,String> entry=ite.next();
            System.out.println(entry.getKey()+" "+entry.getValue());
        }
        
        
        //Enumerados
        EstadoCivil estado=EstadoCivil.CASADO;
        
        
        //Iteradores
        Set<String>semana=Set.of("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo");
        //semana.forEach(System.out::println);
        Iterator<String>it=semana.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
        
    }
}
