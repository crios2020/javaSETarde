package clase06;

public enum EstadoCivil { 
    SOLTERO, 
    CASADO, 
    VIUDO, 
    DIVORCIADO 
}
