package clase05;

import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Lector implements Closeable{
    private FileReader in;
    
    public Lector(String file) throws FileNotFoundException{
        in=new FileReader(file);
    }
    
    public int leer() throws IOException{
        return in.read();
        //return 0;
    }

    @Override
    public void close() throws IOException {
        System.out.println("Se ejecuto el método .close()");
        in.close();
    }
}
