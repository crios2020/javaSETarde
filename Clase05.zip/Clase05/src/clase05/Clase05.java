package clase05;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Clase05 {

    public static void main(String[] args) {
        // Clase 05
        
        //System.out.println(10/0);
        //System.out.println("Esta sentencia no se ejecuta!");
        
        /*
        Estructura Try - Catch - Finally
        
        try{                            Obligatorio
        
            //Colocar aca las sentencias que pueden arrojar una Exception.
            //Estas sentencias tienen más costo de Hardware.
            //Si las sentencia se ejecutan normalmente, el bloque termina sin error
            //Si alguna sentecia lanza una Exception, el control de ejecución pasa
            // al bloque catch.
        
        } catch (Exception e){          Obligatorio
        
            // Este bloque se ejecuta en caso de existir una Exception en el bloque try
            // Se recibe como parametro un objecto de Exception, con las caracticas del error   
        
        } Finally {                     Opcional
        
            // Este bloque se ejecuta siempre.
            // Las variables declaradas en bloque try o catch estan fuera de scope
        }
        
        //El programa termina normalmente
        */
        
        /*
        try{
            System.out.println(10/0);
            System.out.println("Esta sentencia no se ejecuta!");
        }catch(Exception e){
            System.out.println("Ocurrio un error!");
            System.out.println(e);
        }finally{
            System.out.println("El programa termina normalmente!");
        }
        */
        
        //GeneradorExceptions.generar("Hola", 20);
        //FileReader in=new FileReader("texto.txt");
        
        try {
            //GeneradorExceptions.generar();
            //GeneradorExceptions.generar(true);
            //GeneradorExceptions.generar("38x");
            //GeneradorExceptions.generar(null, 2);
            //GeneradorExceptions.generar("Hola", 20);
            //FileReader in=new FileReader("texto.txt");
            
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("El programa termina normalmente!");
        
        
        //Capturas personalizadas de Exceptions
        try {
            //GeneradorExceptions.generar();
            //GeneradorExceptions.generar(true);
            //GeneradorExceptions.generar("38x");
            //GeneradorExceptions.generar(null, 2);
            //GeneradorExceptions.generar("Hola", 20);
            FileReader in=new FileReader("texto.txt");
        //} catch (RuntimeException e) { System.out.println("");
        //} catch (ArrayIndexOutOfBoundsException e) { System.out.println("Indice fuera de rango!");
        } catch (ArithmeticException e) { System.out.println("División / 0");
        } catch (NumberFormatException e) { System.out.println("Formato de Número Incorrecto!");
        } catch (NullPointerException e) { System.out.println("Puntero Nulo");
        //} catch (StringIndexOutOfBoundsException e) { System.out.println("Indice fuera de rango!");
        //} catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e){ System.out.println("Indice fuera de rango!");
        } catch (IndexOutOfBoundsException e) {  System.out.println("Indice fuera de rango!");
        } catch (FileNotFoundException e) { System.out.println("Archivo no Encontrado!");
        } catch (IOException e) { System.out.println("Problemas de Lectura y Escritura!");
        } catch (Exception e) { System.out.println("Ocurrio un error no esperado!");
        }
        
        
        // Uso de Exception para validar reglas de negocio
      
        System.out.println("Sistema de Vuelos!!");
        Vuelo v1=new Vuelo("AER1234",100);
        Vuelo v2=new Vuelo("LAT1111",100);
        
        System.out.println("Venta de pasajes.");
        try {
            v1.venderPasajes(40);
            v2.venderPasajes(20);
            v1.venderPasajes(40);
            v2.venderPasajes(30);
            v1.venderPasajes(40);       //Lanza una exception  
            v2.venderPasajes(20);       //Esta venta no se ejecuta
        } catch (NoHayMasPasajesException ex) {
            System.out.println(ex);
        }
        
        
       
        
        
        //Esto no se debe hacer
        /*
        try {
            Lector lector=new Lector("texto.txt");
            try {

                System.out.println(lector.leer());
                lector.close();
            } catch (Exception e) {
                System.out.println(e);
            } finally {
                if(lector!=null){
                    try{
                        lector.close();
                    }catch(Exception e){
                        System.out.println(e);
                    }
                }
            }
        } catch(Exception e){
            System.out.println(e);
        }
        */
        
        
        
        // Try with resources y Interface AutoClosable          // JDK 7 o superior.
        try (Lector lector=new Lector("texto.txt")) {
            System.out.println(lector.leer());
            //lector.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        
        byte edad=32;       // 1 byte
        
        // edad=32          // 4 byte  int edad=32; 
        
        
    }
    
}
