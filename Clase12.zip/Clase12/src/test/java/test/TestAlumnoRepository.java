package test;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.AlumnoRepository;

//JUnit 5
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

//JUnit 4 Deprecated
//import static junit.framework.Assert.assertEquals;
//import org.junit.Test;


public class TestAlumnoRepository {
    private I_AlumnoRepository ar=new AlumnoRepository(Connector.getConnection());
    private int id=0;
    
    @Test
    public void testSave1(){
        Alumno alumno=new Alumno("Fernando","Gomez",18,1);
        ar.save(alumno);
        assertEquals(true, alumno.getId()>id);
        id=alumno.getId();
    }
    
    @Test
    public void testSave2(){
        Alumno alumno=new Alumno("Dario","Herrera",28,1);
        ar.save(alumno);
        assertEquals(true, alumno.getId()>id);
        id=alumno.getId();
    }
    
    @Test
    public void testSave3(){
        Alumno alumno=new Alumno("Laura","Casas",28,1);
        ar.save(alumno);
        assertEquals(true, alumno.getId()>id);
        id=alumno.getId();
    }
    
    @Test
    public void testSave4(){
        Alumno alumno=new Alumno("Maria","Herrera",28,1);
        ar.save(alumno);
        assertEquals(true, alumno.getId()>id);
        id=alumno.getId();
    }
    
}
