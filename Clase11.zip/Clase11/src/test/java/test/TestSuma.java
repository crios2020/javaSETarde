package test;

import ar.com.eduit.curso.java.test.Suma;

//JUnit 5
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

//JUnit 4 Deprecated
//import static junit.framework.Assert.assertEquals;
//import org.junit.Test;

public class TestSuma {
    private Suma suma=new Suma();
    
    @Test
    public void suma1(){
        assertEquals(2, suma.sumar(1, 1));
    }
    
    @Test
    public void suma2(){
        assertEquals(4, suma.sumar(2, 2));
    }
    
    @Test
    public void suma3(){
        assertEquals(-2, suma.sumar(-1, -1));
    }
    
    @Test
    public void suma4(){
        assertEquals(0, suma.sumar(2, -2));
    }
}
