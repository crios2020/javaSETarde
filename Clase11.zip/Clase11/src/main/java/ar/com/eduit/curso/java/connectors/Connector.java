package ar.com.eduit.curso.java.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {
    
//    private String driver="org.mariadb.jdbc.Driver";
//    private String url="jdbc:mariadb://localhost:3306/colegio";
//    private String user="root";
//    private String pass="";
    
    private String driver="org.postgresql.Driver";
    private String url="jdbc:postgresql://tuffi.db.elephantsql.com:5432/gdyhittm";
    private String user="gdyhittm";
    private String pass="3pJiSBDlGj5FbzcM-gTRP4y_NIu81RJg";

    public Connector() {
    }
    
    public Connector(String url, String user, String pass) {
        this.url=url;
        this.user=user;
        this.pass=pass;
    }
    
    public Connection getConnection(){
        try{
            Class.forName(driver);
            return DriverManager.getConnection(url, user, pass);
        }catch(Exception e){
            System.out.println(e);
            return null;
        }
    }
}
